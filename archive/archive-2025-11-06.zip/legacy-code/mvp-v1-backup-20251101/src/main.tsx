// src/main.tsx
// 엔트리 포인트를 유지하기 위한 래퍼. 실제 초기화 로직은 src/app/main.tsx에 위치.
import './app/main';
