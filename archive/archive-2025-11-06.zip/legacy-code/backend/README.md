***REMOVED***Backend Legacy Handlers

Cloudflare Functions 백엔드에서 사용되지 않는 과거 핸들러/서비스 코드를 보존합니다. 프로덕션 반영 전에는 이 폴더 내용이 로딩되지 않도록 해야 합니다.
