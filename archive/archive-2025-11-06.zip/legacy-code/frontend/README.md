***REMOVED***Frontend Legacy Components

이 폴더에는 현재 프로덕션에서 사용하지 않는 React 컴포넌트와 관련 자산을 보존합니다. 필요 시 Git 히스토리 대신 이 폴더를 우선 참고하세요.
