***REMOVED***Legacy Code Archive

이 디렉터리는 CandleSpinner 프로젝트에서 현재 사용하지 않는 코드 자산을 보존하기 위한 공간입니다. 모든 파일은 참고용으로만 유지하며, 수정 없이 읽기 전용으로 취급합니다.

#***REMOVED***구조

- `frontend/`: 더 이상 사용하지 않는 React 컴포넌트, 훅, 유틸 등 프론트엔드 자산
- `backend/`: 폐기된 Cloudflare Functions 핸들러, 서비스 코드 등 백엔드 자산

#***REMOVED***관리 원칙

1. 신규 레거시 파일은 이동 전 SSOT와 칸반에 반영합니다.
2. 복원이 필요한 경우 Git 기록 대신 본 아카이브를 우선 확인합니다.
3. PoC 폴더는 아카이브 대상에서 제외하며, 기존 위치를 유지합니다.
