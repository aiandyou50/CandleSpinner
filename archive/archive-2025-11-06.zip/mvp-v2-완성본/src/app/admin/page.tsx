/**
 * 관리자 페이지 라우팅
 */

import { AdminWithdrawals } from '@/components/AdminWithdrawals';

export function AdminPage() {
  return <AdminWithdrawals />;
}
