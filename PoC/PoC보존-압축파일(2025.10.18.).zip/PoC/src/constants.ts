// src/constants.ts
export const GAME_WALLET_ADDRESS = "UQBFPDdSlPgqPrn2XwhpVq0KQExN2kv83_batQ-dptaR8Mtd";
export const CSPIN_TOKEN_ADDRESS = "EQBZ6nHfmT2wct9d4MoOdNPzhtUGXOds1y3NTmYUFHAA3uvV";
export const TON_CONNECT_MANIFEST_URL = "https://aiandyou.me/tonconnect-manifest.json";
