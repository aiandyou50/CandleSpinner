// src/PoCComponent.tsx
import React, { useState } from 'react';
import { PayloadBuilder } from './components/PayloadBuilder.js';
import { useTonConnect } from './hooks/useTonConnect.js';
import { useRpc } from './hooks/useRpc.js';
import type { EvidenceItem, BalanceData } from './types.js';

export const PoCComponent: React.FC = () => {
  const { connectedWallet, tonConnectUI, manualJettonWallet, setManualJettonWallet, deriveStatus } = useTonConnect();
  const { rpcUrl, setRpcUrl, pingResult, pingTimestamp, performPing } = useRpc();

  const [busy, setBusy] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const [showDeepLink, setShowDeepLink] = useState(false);
  const [lastTxJson, setLastTxJson] = useState<string | null>(null);
  const [manualEvidenceText, setManualEvidenceText] = useState<string>('');
  const [evidenceList, setEvidenceList] = useState<EvidenceItem[]>([]);
  const [jettonBalance, setJettonBalance] = useState<string | null>(null);
  const [jettonBalanceRaw, setJettonBalanceRaw] = useState<string | null>(null);
  const [tonBalance, setTonBalance] = useState<string | null>(null);
  const [balanceCheckStatus, setBalanceCheckStatus] = useState<string | null>(null);
  const [indexerUrl, setIndexerUrl] = useState<string>('');
  const [indexerApiKey, setIndexerApiKey] = useState<string>('');
  const [forceTokenPresentation, setForceTokenPresentation] = useState<boolean>(true);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<string | null>(null);

function buildJettonTransferPayload(amount: bigint, destination: Address, responseTo: Address | null) {
  const resp = responseTo ? responseTo : Address.parse(ZERO_ADDRESS_BOC);
  const cell = beginCell()
    .storeUint(0xF8A7EA5, 32)
    .storeUint(0, 64)
    .storeCoins(amount)
    .storeAddress(destination)
    .storeAddress(resp)
    .storeCoins(BigInt(0))
    .endCell();
  return cell;
}

function ensureMessageAmount(forwardTon: bigint, diagnostic: boolean) : bigint {
  const feeMargin = diagnostic ? toNano('0.05') : toNano('1.1');
  return forwardTon + feeMargin;
}

function buildJettonTransferPayloadVariant(amount: bigint, destination: Address, responseTo: Address | null, forwardTon: bigint = BigInt(0), opcodeOverride?: number) {
  const op = typeof opcodeOverride === 'number' ? opcodeOverride : 0xF8A7EA5;
  const resp = responseTo ? responseTo : Address.parse(ZERO_ADDRESS_BOC);
  const cell = beginCell()
    .storeUint(op, 32)
    .storeUint(0, 64)
    .storeCoins(amount)
    .storeAddress(destination)
    .storeAddress(resp)
    .storeCoins(forwardTon)
    .endCell();
  return cell;
}

export const PoCComponent: React.FC = () => {
  const connectedWallet = useTonWallet();
  const [tonConnectUI] = useTonConnectUI();

  const [depositAmount, setDepositAmount] = useState<string>("100");
  const [sendType, setSendType] = useState<'CSPIN'|'TON'>('CSPIN');
  const [busy, setBusy] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const [txPreview, setTxPreview] = useState<any | null>(null);
  const [showDeepLink, setShowDeepLink] = useState(false);
  const [decodedPayloadHex, setDecodedPayloadHex] = useState<string | null>(null);
  const [decodedCellInfo, setDecodedCellInfo] = useState<string | null>(null);
  const [includeResponseTo, setIncludeResponseTo] = useState<boolean>(true);
  const [useDiagnosticLowFee, setUseDiagnosticLowFee] = useState<boolean>(false);
  const [sendToTokenMaster, setSendToTokenMaster] = useState<boolean>(true);
  const [lastTxJson, setLastTxJson] = useState<string | null>(null);
  const [manualJettonWallet, setManualJettonWallet] = useState<string>('');
  const [indexerUrl, setIndexerUrl] = useState<string>('');
  const [indexerApiKey, setIndexerApiKey] = useState<string>('');
  // 수동 증빙(state)
  const [manualEvidenceText, setManualEvidenceText] = useState<string>('');
  const [evidenceList, setEvidenceList] = useState<Array<{ id: string; name: string; content: string; type: 'text' | 'file'; created: number }>>([]);
  const [jettonBalance, setJettonBalance] = useState<string | null>(null); // in human-readable units (string)
  const [jettonBalanceRaw, setJettonBalanceRaw] = useState<string | null>(null); // raw smallest units
  const [tonBalance, setTonBalance] = useState<string | null>(null); // in TON (string)
  const [balanceCheckStatus, setBalanceCheckStatus] = useState<string | null>(null);
  const [pocMode, setPocMode] = useState<boolean>(false);
  // default to Pages Functions path for RPC proxy
  const [rpcUrl, setRpcUrl] = useState<string>('/api/rpc');
  const [deriveStatus, setDeriveStatus] = useState<string | null>(null);
  const [forceTokenPresentation, setForceTokenPresentation] = useState<boolean>(true);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<string | null>(null);
  const [pingResult, setPingResult] = useState<any | null>(null);
  const [pingTimestamp, setPingTimestamp] = useState<number | null>(null);

  // performPing: try rpc ping with retries, then fallback to /api/rpc/health or OPTIONS if ping fails
  const performPing = async (maxRetries = 2) => {
    setBusy(true);
    const attempts: any[] = [];
    try {
      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
          const body = { rpcBody: { jsonrpc: '2.0', id: 1, method: 'net.ping', params: [] } };
          const resp = await rpcFetch('/api/rpc', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
          const j = await resp.json().catch(() => null);
          attempts.push({ attempt, ok: resp.ok, status: resp.status, body: j });
          if (resp.ok) {
            setPingResult({ kind: 'rpc.ping', attempts });
            setPingTimestamp(Date.now());
            return { attempts };
          }
        } catch (e) {
          attempts.push({ attempt, error: String(e) });
          // small backoff
          await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
          continue;
        }
      }

      // ping attempts exhausted — try health endpoints
      try {
        // try GET /api/rpc/health
        const hResp = await rpcFetch('/api/rpc/health', { method: 'GET' });
        const hText = await hResp.text().catch(() => null);
        attempts.push({ kind: 'health.get', ok: hResp.ok, status: hResp.status, body: hText });
        setPingResult({ kind: 'health.get', attempts });
        setPingTimestamp(Date.now());
        return { attempts };
      } catch (e) {
        // try OPTIONS on /api/rpc
        try {
          const oResp = await rpcFetch('/api/rpc', { method: 'OPTIONS' });
          const oText = await oResp.text().catch(() => null);
          attempts.push({ kind: 'options', ok: oResp.ok, status: oResp.status, body: oText });
          setPingResult({ kind: 'options', attempts });
          setPingTimestamp(Date.now());
          return { attempts };
        } catch (e2) {
          attempts.push({ kind: 'health-failed', error: String(e2) });
          setPingResult({ kind: 'failed', attempts });
          setPingTimestamp(Date.now());
          return { attempts };
        }
      }
    } finally {
      setBusy(false);
    }
  };

  // expose a console helper so you can paste a TX JSON in devtools and resend it
  React.useEffect(() => {
    try {
      (window as any).sendTestTx = async (tx: any) => {
        if (!tonConnectUI) throw new Error('tonConnectUI not available');
        console.log('window.sendTestTx invoked', tx);
        return await tonConnectUI.sendTransaction(tx as any);
      };
    } catch (e) {
      console.warn('failed to install window.sendTestTx helper', e);
    }
    // no cleanup: keep helper available for debugging during session
  }, [tonConnectUI]);

  // Auto-derive on connect: try to fill manualJettonWallet automatically when wallet connects
  React.useEffect(() => {
    const tryDeriveOnConnect = async () => {
      try {
        if (!connectedWallet) return;
        // if manual already set, skip
        if (manualJettonWallet && manualJettonWallet.length > 0) return;
        // try ton-core first
        try {
          const ton = await import('ton-core');
          if ((ton as any).getJettonWalletAddress) {
            const res = (ton as any).getJettonWalletAddress(CSPIN_TOKEN_ADDRESS, connectedWallet.account.address);
            if (res) { setManualJettonWallet(res.toString()); setDeriveStatus('파생 성공 (ton-core)'); return; }
          }
        } catch (e) {
          // ignore, will try RPC fallback
        }

        // RPC fallback if rpcUrl configured
        if (rpcUrl) {
          setDeriveStatus('RPC로 파생 시도 중...');
          const getterCandidates = ['get_wallet_address','get_wallet','wallet_of','walletOf','getWalletAddress'];
          for (const method of getterCandidates) {
            try {
              const body = { jsonrpc: '2.0', id: 1, method: 'run_get_method', params: [CSPIN_TOKEN_ADDRESS, method, [{ type: 'address', value: connectedWallet.account.address }]] };
              const resp = await rpcFetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
              if (!resp.ok) continue;
              const j = await resp.json();
              const txt = JSON.stringify(j.result || j);
              const addrRegex = /(?:EQ|UQ|Ef)[A-Za-z0-9_-]{40,60}/g;
              const m = txt.match(addrRegex);
              if (m && m.length > 0) { setManualJettonWallet(m[0]); setDeriveStatus('파생 성공 (RPC)'); return; }
            } catch (e) { continue; }
          }
          setDeriveStatus('RPC로도 파생 실패');
        } else {
          setDeriveStatus('ton-core에서 헬퍼를 찾을 수 없습니다. RPC URL을 입력하면 RPC로 파생 시도합니다.');
        }
      } catch (err) {
        console.warn('auto derive on connect failed', err);
      }
    };
    tryDeriveOnConnect();
    // run whenever wallet or rpcUrl changes
  }, [connectedWallet, rpcUrl]);

  // Removed automatic derivation: PoC now relies on manual jetton-wallet input or token master mode.

  // Helper: attempt to fetch jetton balance and TON balance using a configurable indexer endpoint.
  const fetchBalances = async () => {
    setBalanceCheckStatus('조회 중...');
    setJettonBalance(null);
    setJettonBalanceRaw(null);
    setTonBalance(null);

    const ownerAddr = connectedWallet?.account?.address;
    if (!ownerAddr) {
      setBalanceCheckStatus('연결된 지갑 주소를 찾을 수 없습니다. 지갑을 다시 연결하세요.');
      return;
    }

    // Need a jetton-wallet address to check token balance; prefer manual input
    const jettonWallet = manualJettonWallet && manualJettonWallet.length > 0 ? manualJettonWallet : null;
    if (!jettonWallet) {
      setBalanceCheckStatus('수동 jetton-wallet 주소가 필요합니다. "보내기 대상: Token Master 사용"을 끄고 jetton-wallet 주소를 입력하세요. 또는 Auto-derive 버튼으로 파생 시도');
      return;
    }

    // build common fetch options
    const headers: Record<string,string> = { 'Content-Type': 'application/json' };
    if (indexerApiKey) headers['X-API-Key'] = indexerApiKey;

    try {
      // Try a few common indexer GET shapes. Responses differ across indexers, so parse heuristically.
      // 1) Try: { balance: '123' } or { result: { balance: '123' } }
      const tryUrls = [
        // toncenter-style endpoint guesses
        `${indexerUrl}/getAccount?address=${encodeURIComponent(jettonWallet)}`,
        `${indexerUrl}/getAddressInformation?address=${encodeURIComponent(jettonWallet)}`,
        // generic account info
        `${indexerUrl}/accounts/${encodeURIComponent(jettonWallet)}`,
        // direct jetton-wallet query placeholder (some indexers expose jetton endpoints)
        `${indexerUrl}/jetton/${encodeURIComponent(jettonWallet)}`,
      ];

      let parsed: any = null;
      let ok = false;
      for (const url of tryUrls) {
        try {
          const resp = await fetch(url, { method: 'GET', headers });
          if (!resp.ok) continue;
          const j = await resp.json();
          // try to find a numeric balance field in common locations
          const candidates = [j, j.result, j.data, j.account, j.accountState, j.balance, j.result?.balance, j.data?.balance, j.account?.balance, j.result?.data];
          // flatten any nested objects to search for numeric-like values
          const flat = JSON.stringify(candidates);
          if (flat.includes('balance') || flat.match(/\d{2,}/)) {
            parsed = j;
            ok = true;
            break;
          }
        } catch (e) {
          // ignore and try next
          continue;
        }
      }

      if (!ok || !parsed) {
        // If indexer failed, try RPC fallback if RPC URL is provided
        if (rpcUrl) {
          setBalanceCheckStatus('인덱서에서 정보를 찾지 못해 RPC로 시도합니다...');
          try {
            const masterAddr = CSPIN_TOKEN_ADDRESS;
            const ownerAddrRPC = ownerAddr;
            const getterCandidates = ['get_wallet_address','get_wallet','wallet_of','walletOf','getWalletAddress'];
            let derivedAddr: string | null = null;
            for (const method of getterCandidates) {
              try {
                const body = { jsonrpc: '2.0', id: 1, method: 'run_get_method', params: [masterAddr, method, [{ type: 'address', value: ownerAddrRPC }]] };
                const resp = await rpcFetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
                if (!resp.ok) continue;
                const j = await resp.json();
                const txt = JSON.stringify(j.result || j);
                const addrRegex = /(?:EQ|UQ|Ef)[A-Za-z0-9_-]{40,60}/g;
                const matches = txt.match(addrRegex);
                if (matches && matches.length > 0) { derivedAddr = matches[0]; break; }
              } catch (e) { continue; }
            }
            if (!derivedAddr) {
              setBalanceCheckStatus('RPC로도 jetton-wallet 주소를 찾을 수 없습니다.');
              return;
            }

            // Now query the jetton-wallet for its token balance using common getter names
            const balanceGetters = ['get_balance','balance','getWalletBalance','getWalletData'];
            let rawBal: string | null = null;
            for (const bg of balanceGetters) {
              try {
                const bbody = { jsonrpc: '2.0', id: 1, method: 'run_get_method', params: [derivedAddr, bg, []] };
                const rresp = await rpcFetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(bbody) });
                if (!rresp.ok) continue;
                const jj = await rresp.json();
                // try to parse known shapes
                // 1) result.stack with int value
                if (jj?.result?.stack && Array.isArray(jj.result.stack)) {
                  for (const el of jj.result.stack) {
                    if (el?.type === 'int' && el?.value) { rawBal = String(el.value); break; }
                    if (el?.type === 'num' && el?.value) { rawBal = String(el.value); break; }
                  }
                }
                // 2) fallback: search any digits in JSON
                if (!rawBal) {
                  const txt2 = JSON.stringify(jj.result || jj);
                  const m2 = txt2.match(/\d{3,}/);
                  if (m2) rawBal = m2[0];
                }
                if (rawBal) break;
              } catch (e) { continue; }
            }
            if (!rawBal) {
              setBalanceCheckStatus('RPC에서 잔액을 추출할 수 없습니다. RPC 응답을 확인하세요.');
              console.log('derivedAddr', derivedAddr);
              return;
            }
            setJettonBalanceRaw(rawBal);
            const dec = 9;
            let human = rawBal;
            if (dec > 0) {
              while (human.length <= dec) human = '0' + human;
              const intPart = human.slice(0, human.length - dec);
              const fracPart = human.slice(human.length - dec).replace(/0+$/,'');
              human = fracPart.length > 0 ? `${intPart}.${fracPart}` : `${intPart}`;
            }
            setJettonBalance(human);
            setBalanceCheckStatus('RPC 기반 잔액 조회 완료');
            return;
          } catch (err) {
            console.error('RPC balance fallback failed', err);
            setBalanceCheckStatus('RPC 기반 잔액 조회 중 오류가 발생했습니다. 콘솔을 확인하세요.');
            return;
          }
        }
        setBalanceCheckStatus('인덱서에서 jetton 잔액 정보를 찾을 수 없습니다. 올바른 indexer URL 또는 API 키를 입력하세요.');
        return;
      }

      // Heuristically extract a balance and decimals if present
      // Look for common shapes: parsed.balance, parsed.result.balance, parsed.tokens[...].balance, etc.
      let rawBalance: string | null = null;
      let decimals: number | null = null;

      // helper to try to pluck numeric-like fields
      const pluckNumberString = (obj: any): string | null => {
        if (!obj) return null;
        if (typeof obj === 'string' && /^\d+$/.test(obj)) return obj;
        if (typeof obj === 'number') return String(obj);
        if (typeof obj === 'object') {
          for (const k of ['balance', 'value', 'amount']) {
            if (obj[k] !== undefined && (typeof obj[k] === 'string' || typeof obj[k] === 'number')) {
              const v = String(obj[k]);
              if (/^\d+$/.test(v)) return v;
            }
          }
          // inspect arrays of tokens
          for (const key of Object.keys(obj)) {
            const val = obj[key];
            if (Array.isArray(val)) {
              for (const it of val) {
                const r = pluckNumberString(it);
                if (r) return r;
              }
            } else if (typeof val === 'object') {
              const r = pluckNumberString(val);
              if (r) return r;
            }
          }
        }
        return null;
      };

      rawBalance = pluckNumberString(parsed) ?? null;
      // decimals heuristics
      if (parsed && typeof parsed.decimals === 'number') decimals = parsed.decimals;
      if (!decimals && parsed?.token && typeof parsed.token.decimals === 'number') decimals = parsed.token.decimals;

      if (!rawBalance) {
        setBalanceCheckStatus('인덱서 응답에서 잔액을 추출할 수 없습니다. 응답을 콘솔에서 확인하세요.');
        console.log('Indexer parsed object:', parsed);
        return;
      }

      setJettonBalanceRaw(rawBalance);
      const dec = decimals ?? 9;
      // convert raw (smallest units) to human-readable string
      let human = rawBalance;
      if (dec > 0) {
        // pad
        while (human.length <= dec) human = '0' + human;
        const intPart = human.slice(0, human.length - dec);
        const fracPart = human.slice(human.length - dec).replace(/0+$/,'');
        human = fracPart.length > 0 ? `${intPart}.${fracPart}` : `${intPart}`;
      }
      setJettonBalance(human);

      // TON balance: attempt simple account info fetch for connected wallet address
      try {
        const tonUrl = `${indexerUrl}/getAccount?address=${encodeURIComponent(ownerAddr)}`;
        const resp2 = await fetch(tonUrl, { method: 'GET', headers });
        if (resp2.ok) {
          const j2 = await resp2.json();
          // try common paths
          let tonRaw: string | null = null;
          if (j2.balance) tonRaw = String(j2.balance);
          if (!tonRaw && j2.result && j2.result.balance) tonRaw = String(j2.result.balance);
          if (!tonRaw && j2.account && j2.account.balance) tonRaw = String(j2.account.balance);
          if (tonRaw) {
            // tonRaw may be in nanotons
            // If value is very large, assume nanotons -> convert to TON
            let tonHuman = tonRaw;
            if (/^\d+$/.test(tonRaw)) {
              // convert from nanoton to TON
              while (tonHuman.length <= 9) tonHuman = '0' + tonHuman;
              const intP = tonHuman.slice(0, tonHuman.length - 9);
              const fracP = tonHuman.slice(tonHuman.length - 9).replace(/0+$/,'');
              tonHuman = fracP.length > 0 ? `${intP}.${fracP}` : `${intP}`;
            }
            setTonBalance(tonHuman);
          }
        }
      } catch (e) {
        // ignore ton balance failure
        console.warn('TON balance fetch failed', e);
      }

      setBalanceCheckStatus('잔액 조회 완료');
    } catch (err) {
      console.error('fetchBalances failed', err);
      setBalanceCheckStatus('잔액 조회 중 오류가 발생했습니다. 콘솔을 확인하세요.');
    }
  };

  // Auto-derive jetton-wallet address using ton-core helpers if available (dynamic import)
  const tryAutoDerive = async () => {
    setDeriveStatus('파생 시도 중...');
    try {
      const masterAddr = CSPIN_TOKEN_ADDRESS;
      const ownerAddr = connectedWallet?.account?.address;
      if (!ownerAddr) { setDeriveStatus('연결된 지갑 주소를 찾을 수 없습니다. 지갑을 연결하세요.'); return; }
      // dynamic import to avoid always bundling ton-core
      const ton = await import('ton-core');
      // try common helper names
      let derived: any = null;
      if ((ton as any).getJettonWalletAddress) {
        derived = (ton as any).getJettonWalletAddress(masterAddr, ownerAddr);
      } else if ((ton as any).JettonWallet && typeof (ton as any).JettonWallet.getAddress === 'function') {
        derived = (ton as any).JettonWallet.getAddress(masterAddr, ownerAddr);
      }
      if (!derived) {
        setDeriveStatus('ton-core에서 jetton 유도 헬퍼를 찾을 수 없습니다. RPC 시도로 대체합니다...');
        // attempt RPC-based getter if rpcUrl provided
        if (rpcUrl) {
          try {
            const body = {
              jsonrpc: '2.0', id: 1, method: 'run_get_method', params: [masterAddr, 'get_wallet_address', [ { type: 'address', value: ownerAddr } ]]
            };
            const resp = await rpcFetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
            if (!resp.ok) throw new Error('RPC 응답이 정상이 아닙니다: ' + resp.status);
            const j = await resp.json();
            // try to extract address-like string from result
            const res = j.result || j;
            // robust search for friendly TON addresses (common prefixes EQ, UQ, Ef, etc.)
            const txt = JSON.stringify(res);
            const addrRegex = /(?:EQ|UQ|Ef)[A-Za-z0-9_-]{40,60}/g;
            const matches = txt.match(addrRegex);
            if (matches && matches.length > 0) {
              // pick the first candidate
              const candidate = matches[0];
              try {
                // validate via ton-core Address.parse if available
                try {
                  const tonCore = await import('ton-core');
                  try { tonCore.Address.parse(candidate); } catch { throw new Error('invalid address'); }
                } catch (e) {
                  // if ton-core not available, accept candidate heuristically
                }
                setManualJettonWallet(candidate);
                setDeriveStatus('RPC 파생 성공: ' + candidate);
                return;
              } catch (e) {
                console.warn('candidate address validation failed', e);
              }
            }
            setDeriveStatus('RPC 응답에서 주소를 추출할 수 없습니다. 콘솔을 확인하세요.');
            console.log('RPC result', j);
            return;
          } catch (e) {
            console.error('RPC derive failed', e);
            setDeriveStatus('RPC 기반 파생 실패: ' + String(e));
            return;
          }
        }
        setDeriveStatus('ton-core에서 jetton 유도 헬퍼를 찾을 수 없습니다. RPC URL을 입력하면 RPC 기반 파생을 시도합니다.');
        return;
      }
      const asStr = derived.toString();
      setManualJettonWallet(asStr);
      setDeriveStatus('파생 성공: ' + asStr);
    } catch (err) {
      console.error('auto derive failed', err);
      setDeriveStatus('파생 실패: ' + String(err));
    }
  };

  const handleDeposit = async () => {
    if (!connectedWallet) {
      alert("지갑을 먼저 연결해주세요.");
      return;
    }

    try {
      setBusy(true);

      // Adjust decimals according to token decimals; default 9
      const DECIMALS = 9n;
      const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
      const amount = amountWhole * 10n ** DECIMALS;

    // We need to send the jetton-transfer payload to the user's jetton-wallet contract (so tokens are deducted from user).
    // payload.destination must be the game's receive address (GAME_WALLET_ADDRESS). The message address (where we send the message)
    // should be the user's jetton-wallet (manual input or RPC-derived).
    const ownerAddrStr = connectedWallet.account.address;
    let userJettonWalletAddrStr: string | null = (manualJettonWallet && manualJettonWallet.length > 0) ? manualJettonWallet : null;

    // If user didn't provide a manual jetton-wallet, try an RPC-based derivation here (synchronously) when rpcUrl is available.
    if (!userJettonWalletAddrStr) {
      if (rpcUrl) {
        setDeriveStatus('입금용 jetton-wallet을 RPC로 파생 중...');
        const getterCandidates = ['get_wallet_address','get_wallet','wallet_of','walletOf','getWalletAddress'];
        try {
          for (const method of getterCandidates) {
            try {
              const body = { jsonrpc: '2.0', id: 1, method: 'run_get_method', params: [CSPIN_TOKEN_ADDRESS, method, [{ type: 'address', value: ownerAddrStr }]] };
              const resp = await rpcFetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
              if (!resp.ok) continue;
              const j = await resp.json();
              const txt = JSON.stringify(j.result || j);
              const addrRegex = /(?:EQ|UQ|Ef)[A-Za-z0-9_-]{40,60}/g;
              const matches = txt.match(addrRegex);
              if (matches && matches.length > 0) { userJettonWalletAddrStr = matches[0]; break; }
            } catch (e) { continue; }
          }
        } catch (e) {
          console.warn('입금 파생 RPC 시도 중 오류', e);
        }
      }
    }

    if (!userJettonWalletAddrStr) {
      throw new Error('Jetton-wallet 주소를 찾을 수 없습니다. 수동으로 jetton-wallet 주소를 입력하거나 RPC URL을 제공하고 Auto-derive를 시도하세요.');
    }

    // Build payload: destination is GAME_WALLET_ADDRESS (the game's receive address)
    const payloadDestination = Address.parse(GAME_WALLET_ADDRESS as string);
    const responseAddress = includeResponseTo ? Address.parse(connectedWallet.account.address) : null;
    const payloadCell = buildJettonTransferPayload(amount, payloadDestination, responseAddress);
    const payloadBase64 = payloadCell.toBoc().toString('base64');

    // validUntil: TonConnect expects validUntil not too far in the future — keep 5 minutes
    const VALID_SECONDS = 60 * 5; // 5 minutes
    const validUntil = Math.floor(Date.now() / 1000) + VALID_SECONDS;

    // Compute forward amount (we used zero for buildJettonTransferPayload)
    const forwardAmount = BigInt(0);
    // compute required message amount to cover forward + fee margin
    let requiredAmount = ensureMessageAmount(forwardAmount, useDiagnosticLowFee);
    // bump fee when forcing token presentation to avoid wallet simulation failures
    if (forceTokenPresentation) {
      const minFee = toNano('0.15');
      if (requiredAmount < minFee) requiredAmount = minFee;
    }
    const TON_FEE = requiredAmount.toString();

    // Determine tx: for CSPIN we normally send payload to the user's jetton-wallet so the wallet executes the transfer.
    // However many wallets display a token-transfer UI only when the message is sent to the token master contract.
    // Provide option to prefer token-master presentation (sendToTokenMaster or forceTokenPresentation).
    let tx: any;
    if (sendType === 'CSPIN') {
      const recipientAddress = (forceTokenPresentation || sendToTokenMaster) ? CSPIN_TOKEN_ADDRESS : userJettonWalletAddrStr;
      // Safety: do not accidentally set message recipient to the GAME_WALLET_ADDRESS
      if (recipientAddress === (GAME_WALLET_ADDRESS as string)) {
        throw new Error('메시지 수신자가 게임 지갑 주소로 설정되어 있습니다. 메시지는 사용자의 jetton-wallet로 보내야 합니다. manualJettonWallet 값을 확인하세요.');
      }
      tx = {
        validUntil,
        messages: [
          {
            address: recipientAddress,
            amount: TON_FEE,
            payload: payloadBase64,
          },
        ],
      };

      // reflect chosen recipient in preview
      setTxPreview({
        to: recipientAddress,
        amount: TON_FEE,
        validUntil,
        payloadDisplay: payloadBase64.slice(0, 120) + (payloadBase64.length > 120 ? '...' : ''),
        payloadFull: payloadBase64,
        responseTo: responseAddress ? connectedWallet.account.address : null,
      });
    } else {
      // TON native transfer to the game's receive address (not a token transfer)
      tx = {
        validUntil,
        messages: [
          {
            address: payloadDestination.toString(),
            amount: ensureMessageAmount(BigInt(0), useDiagnosticLowFee).toString(),
          },
        ],
      };
      setTxPreview({
        to: payloadDestination.toString(),
        amount: ensureMessageAmount(BigInt(0), useDiagnosticLowFee).toString(),
        validUntil,
        payloadDisplay: '',
        payloadFull: '',
        responseTo: responseAddress ? connectedWallet.account.address : null,
      });
    }

      // Detailed logging to help debug TonConnect delivery issues
      console.log('Prepared tx:', {
        validUntil,
        messages: tx.messages.map((m: any) => ({ address: m.address, amount: m.amount, payloadLen: m.payload ? m.payload.length : 0 })),
      });

      // populate preview for user verification and deep-link help
      setTxPreview({
        to: userJettonWalletAddrStr ?? (payloadDestination ? payloadDestination.toString() : ''),
        amount: TON_FEE,
        validUntil,
        payloadDisplay: payloadBase64.slice(0, 120) + (payloadBase64.length > 120 ? '...' : ''),
        payloadFull: payloadBase64,
        responseTo: responseAddress ? connectedWallet.account.address : null,
      });

      // store full tx json for copy/debug
      try {
        setLastTxJson(JSON.stringify(tx, null, 2));
      } catch (e) {
        setLastTxJson(String(tx));
      }

      // Pre-simulate via RPC proxy if available
      if (rpcUrl && rpcUrl.startsWith('/')) {
        try {
          // call proxy with a run_executor style simulation if backend supports it
          const simBody = { jsonrpc: '2.0', id: 1, method: 'run_executor', params: [tx.messages[0].address, tx.messages[0].payload ? { body: tx.messages[0].payload } : {}, []] };
          const resp = await rpcFetch(rpcUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rpcBody: simBody }) });
          const j = await resp.json();
          setSimResult(JSON.stringify(j));
          // if result indicates an obvious error, show confirm modal to user
          if (j?.error) {
            setShowConfirmModal(true);
          }
        } catch (e) {
          console.warn('simulation failed', e);
        }
      }

      // Simple retry logic for transient bridge/network issues (e.g. rate limit on public bridge)
      let lastErr: any = null;
      const MAX_RETRIES = 2;
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        try {
          const attemptId = `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
          console.log(`sendTransaction attempt ${attempt + 1} id=${attemptId}`);
          // log timestamp for correlating with bridge/wallet logs
          console.log('sendTransaction timestamp:', new Date().toISOString(), 'attemptId=', attemptId, 'useDiagnosticLowFee=', useDiagnosticLowFee);
          const result = await tonConnectUI.sendTransaction(tx as any);
          console.log('sendTransaction result:', result, 'attemptId=', attemptId);
          alert("CSPIN 입금 요청이 생성되었습니다. 지갑에서 트랜잭션을 확인하세요.");
          lastErr = null;
          break;
        } catch (e: any) {
          lastErr = e;
          // richer error logging for debugging: include name/message/stack and any sdk fields
            try {
              console.error(`sendTransaction failed (attempt ${attempt + 1}):`, {
                errorName: e && e.name,
                errorMessage: e && e.message,
                errorStack: e && e.stack,
                raw: e,
              });
            } catch (logErr) {
              console.warn('sendTransaction failed, but error logging also failed', logErr);
              console.warn('original error:', e);
            }
          // normalize message
          let msg = '';
          try { msg = typeof e === 'string' ? e : JSON.stringify(e); } catch { msg = String(e); }

          // if bridge related error or 429/CORS, show deep link option
          if (msg.includes('bridge') || msg.includes('Bridge') || msg.includes('429') || msg.includes('CORS')) {
            setShowDeepLink(true);
          }

          // if error looks like request expired or transaction not sent due to timeout, open deep-link fallback on mobile
          const looksExpired = msg.toLowerCase().includes('expired') || msg.toLowerCase().includes('transaction was not sent') || msg.toLowerCase().includes('not sent');
          if (looksExpired) {
            setShowDeepLink(true);
            // if mobile user agent, attempt to open telegram wallet deep link after short delay
            try {
              const ua = navigator.userAgent || '';
              const isMobile = /Android|iPhone|iPad|Mobile/i.test(ua);
              const openDeepLink = () => {
                // attempt tg resolve deep link
                const tg = `tg://resolve?domain=wallet`;
                try {
                  if (isMobile) {
                    window.location.href = tg;
                  } else {
                    // open in new tab for desktop as fallback
                    window.open('https://wallet.ton.org/', '_blank');
                  }
                } catch (err) {
                  try { window.open('https://wallet.ton.org/', '_blank'); } catch {}
                }
              };
              // schedule open so the current error flow can complete first
              setTimeout(openDeepLink, 900);
            } catch (err) {
              console.warn('deep-link open failed:', err);
            }
          }

          // If final attempt, throw to outer catch
          if (attempt < MAX_RETRIES) {
            // small backoff
            await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
            continue;
          }
        }
      }
      if (lastErr) {
        throw lastErr;
      }
    } catch (err: any) {
      console.error("트랜잭션 에러:", err);
      // Capture structured error for display/copy
      try {
        setLastError(typeof err === 'string' ? err : JSON.stringify(err, Object.getOwnPropertyNames(err), 2));
      } catch (e) {
        setLastError(String(err));
      }

      // Friendly user guidance depending on likely cause
      const msg = [] as string[];
      msg.push("입금 중 오류가 발생했습니다.");
      msg.push("가능한 원인:");
      msg.push(" - 네트워크 또는 브리지(bridge) 서비스 과부하 (공용 브리지에 429 발생)");
      msg.push(" - 지갑의 WebView/캐시 문제 또는 시간 동기화 문제");
      msg.push(" - 수수료 부족(지갑 내 Toncoin 잔액 확인)");
      msg.push("");
      msg.push("권장 조치:");
      msg.push("1) 모바일 Telegram TON Wallet에서 시도하거나 다른 네트워크(모바일 데이터)를 사용하세요.");
      msg.push("2) Telegram 앱 캐시를 지우고 재로그인하세요.");
      msg.push("3) 지갑 주소가 연결된 주소와 동일한지 확인하세요(설정 > Connected Apps).");
      msg.push("4) 문제가 지속되면 오류 상세 정보를 복사하여 앱 개발자나 TON Wallet Support에 전달하세요.");

      alert(msg.join('\n'));
    } finally {
      setBusy(false);
    }
  };

  // Helper: download a debug pack with last TX JSON and payload BOC
  const downloadDebugPack = async () => {
    // Ensure we have a recent ping result; if not, attempt to perform one
    if (!pingResult) {
      try { await performPing(2); } catch (_) { /* ignore */ }
    }

    const parts: Record<string,string> = {};
    if (lastTxJson) parts['tx.json'] = lastTxJson;
    if (txPreview && txPreview.payloadFull) parts['payload.b64.txt'] = txPreview.payloadFull;
    // include last SDK error if present
    if (lastError) parts['lastError.txt'] = lastError;
    // include recent RPC ping result if present
    if (pingResult) {
      const ts = pingTimestamp ? new Date(pingTimestamp).toISOString() : new Date().toISOString();
      parts[`rpc-ping-${ts}.json`] = JSON.stringify(pingResult, null, 2);
    }
    if (Object.keys(parts).length === 0) { alert('다운로드할 디버그 데이터가 없습니다.'); return; }
    const zipContent = Object.entries(parts).map(([name, body]) => `--- ${name} ---\n${body}`).join('\n\n');
    const blob = new Blob([zipContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    // include timestamp in filename
    const now = new Date();
    const stamp = now.toISOString().replace(/[:.]/g,'-');
    a.download = `cspin-debug-pack-${stamp}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  // Manual evidence handlers
  const addManualEvidence = () => {
    if (!manualEvidenceText || manualEvidenceText.trim().length === 0) { alert('증빙 내용을 입력하세요.'); return; }
    const id = `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    setEvidenceList(prev => [{ id, name: `evidence-${prev.length + 1}.txt`, content: manualEvidenceText, type: 'text', created: Date.now() }, ...prev]);
    setManualEvidenceText('');
  };

  const handleFileUpload = async (file: File | null) => {
    if (!file) return;
    const buf = await file.text();
    const id = `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    setEvidenceList(prev => [{ id, name: file.name, content: buf, type: 'file', created: Date.now() }, ...prev]);
  };

  const removeEvidence = (id: string) => {
    setEvidenceList(prev => prev.filter(e => e.id !== id));
  };

  const downloadEvidencePack = () => {
    if (evidenceList.length === 0) { alert('저장된 증빙이 없습니다.'); return; }
    const parts = evidenceList.map(e => `--- ${e.name} ---\n${e.content}`).join('\n\n');
    const blob = new Blob([parts], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'manual-evidence-pack.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  if (!connectedWallet) {
    return <p>게임을 시작하려면 지갑을 연결해주세요.</p>;
  }

  return (
    <div style={{ padding: 12, maxWidth: 980, margin: '0 auto' }}>
      <h2>CSPIN 입금하기</h2>
      <p style={{ wordBreak: 'break-all', overflowWrap: 'break-word' }}>연결된 지갑: {connectedWallet.account.address}</p>

      <div style={{ marginBottom: 8 }}>
        <label>
          입금 수량 (CSPIN):{" "}
          <input
            type="number"
            value={depositAmount}
            onChange={(e) => setDepositAmount(e.target.value)}
            min={0}
            style={{ width: '100%', maxWidth: 160 }}
          />
        </label>
      </div>

      {/* Indexer configuration and balance check */}
      <div style={{ marginTop: 8, padding: 8, border: '1px dashed #ddd' }}>
        <div style={{ marginBottom: 6 }}><strong>인덱서 (잔액조회) 설정</strong></div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <input value={indexerUrl} onChange={(e) => setIndexerUrl(e.target.value)} style={{ width: '100%', maxWidth: 520 }} placeholder="Index API URL (예: https://toncenter.com/api/v2)" />
          <input value={indexerApiKey} onChange={(e) => setIndexerApiKey(e.target.value)} style={{ width: '100%', maxWidth: 220 }} placeholder="API Key (선택)" />
          <button onClick={fetchBalances} disabled={!connectedWallet || !manualJettonWallet} style={{ padding: '6px 10px' }}>잔액 조회</button>
        </div>
        <div style={{ marginTop: 8, color: '#444' }}>
          <div>Jetton 잔액: {jettonBalance ?? '알 수 없음'} {jettonBalanceRaw ? `(${jettonBalanceRaw} raw)` : ''}</div>
          <div>TON 잔액: {tonBalance ?? '알 수 없음'}</div>
            {pingResult && (
              <div style={{ marginTop: 8, padding: 8, border: '1px dashed #ddd', background: '#fafafa' }}>
                <div style={{ fontSize: 13 }}><strong>RPC Ping 결과</strong> <small style={{ color: '#666', marginLeft: 8 }}>{pingTimestamp ? new Date(pingTimestamp).toLocaleString() : ''}</small></div>
                <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12, maxHeight: 180, overflow: 'auto' }}>{JSON.stringify(pingResult, null, 2)}</pre>
              </div>
            )}
          <div style={{ color: '#666' }}>{balanceCheckStatus ?? ''}</div>
          <div style={{ marginTop: 8 }}>
            <div style={{ fontSize: 12, color: '#666' }}>인덱서 없이 RPC로 직접 조회하려면 RPC URL을 입력하고 Auto-derive 또는 RPC 조회를 사용하세요.</div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 6 }}>
              <input value={rpcUrl} onChange={(e) => setRpcUrl(e.target.value)} placeholder="RPC URL (예: https://main.ton.dev)" style={{ width: '100%', maxWidth: 420 }} />
              <button onClick={() => setRpcUrl('https://main.ton.dev')} style={{ padding: '6px 8px' }}>추천: main.ton.dev</button>
              <button onClick={() => setRpcUrl('https://rpc.tonapi.io/jsonRPC')} style={{ padding: '6px 8px' }}>추천: tonapi</button>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginLeft: 8 }}>
                <button onClick={async () => { await performPing(2); }} style={{ padding: '6px 8px' }}>RPC Ping (/api/rpc)</button>
                <button onClick={() => { if (pingResult) { navigator.clipboard.writeText(JSON.stringify(pingResult, null, 2)); alert('Ping 결과가 클립보드에 복사되었습니다.'); } else { alert('Ping 결과가 없습니다. 먼저 RPC Ping을 실행하세요.'); } }} style={{ padding: '6px 8px' }}>Ping 복사</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ marginBottom: 8 }}>
        <label>
          <input
            type="checkbox"
            checked={includeResponseTo}
            onChange={(e) => setIncludeResponseTo(e.target.checked)}
          />{' '}
          Include response_to (send callback to connected wallet)
        </label>
      </div>

      <div style={{ marginBottom: 8 }}>
        <label>
          <input
            type="checkbox"
            checked={useDiagnosticLowFee}
            onChange={(e) => setUseDiagnosticLowFee(e.target.checked)}
          />{' '}
          Diagnostic low fee (0.05 TON) — only for testing
        </label>
      </div>

      <div style={{ marginBottom: 8 }}>
        <label>
          전송 타입:
          <select value={sendType} onChange={(e) => setSendType(e.target.value as any)} style={{ marginLeft: 8 }}>
            <option value="CSPIN">CSPIN 토큰 전송</option>
            <option value="TON">TON(네이티브) 전송</option>
          </select>
        </label>
      </div>

  <button onClick={handleDeposit} disabled={busy || !connectedWallet || (sendType === 'CSPIN' && !pocMode && !sendToTokenMaster && (!jettonBalance || Number(jettonBalance) < Number(depositAmount)) )} style={{ padding: '10px 14px', fontSize: 16, width: '100%', maxWidth: 220 }}>
        {busy ? '처리중...' : (
          // show truncated amount with ellipsis when too long, but indicate full value exists
          (typeof depositAmount === 'string' && depositAmount.length > 12)
            ? `${depositAmount.slice(0,12)}... ${sendType === 'CSPIN' ? 'CSPIN' : 'TON'} 입금`
            : `${depositAmount} ${sendType === 'CSPIN' ? 'CSPIN' : 'TON'} 입금`
        )}
      </button>

      {/* Test buttons container: simple tx and payload tx - aligned */}
      <div style={{ marginTop: 10, display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <button
          onClick={async () => {
            try {
              setBusy(true);
              if (!connectedWallet) {
                alert('지갑을 먼저 연결해주세요.');
                return;
              }
              const VALID_SECONDS = 60 * 5;
              const tx = {
                validUntil: Math.floor(Date.now() / 1000) + VALID_SECONDS,
                messages: [
                  {
                    address: CSPIN_TOKEN_ADDRESS,
                    amount: toNano('0.05').toString(),
                    // intentionally no payload
                  },
                ],
              };
              const txJson = JSON.stringify(tx, null, 2);
              console.log('TEST SIMPLE TX', txJson);
              setLastTxJson(txJson);
              await tonConnectUI.sendTransaction(tx as any);
              alert('간단 전송 요청을 보냈습니다. 지갑에서 확인하세요.');
            } catch (e) {
              console.error('simple tx failed', e);
              alert('간단 전송 실패: ' + (e && (e as any).message ? (e as any).message : String(e)));
            } finally {
              setBusy(false);
            }
          }}
          style={{ padding: '8px 12px', fontSize: 14 }}
        >
          Payload 없이 전송 (테스트)
        </button>

        {/* Payload test button: prepare real jetton transfer payload and send using current diagnostic fee setting */}
        <button
          onClick={async () => {
            try {
              setBusy(true);
              if (!connectedWallet) {
                alert('지갑을 먼저 연결해주세요.');
                return;
              }

              // reuse same logic as handleDeposit for building payload/amount
              const DECIMALS = 9n;
              const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
              const amount = amountWhole * 10n ** DECIMALS;
              const masterAddress = Address.parse(GAME_WALLET_ADDRESS);
              const responseAddress = includeResponseTo ? Address.parse(connectedWallet.account.address) : null;

              // recipient should be the user's jetton-wallet address (derived or manual override)
              const recipient = manualJettonWallet && manualJettonWallet.length > 0 ? manualJettonWallet : null;
              if (!recipient) {
                alert('Jetton wallet 주소를 파생할 수 없습니다. 수동으로 jetton-wallet 주소를 입력하세요.');
                setBusy(false);
                return;
              }
              const toAddress = Address.parse(recipient as string);
              const payloadCell = buildJettonTransferPayload(amount, toAddress, responseAddress);
              const payloadBase64 = payloadCell.toBoc().toString('base64');

              const VALID_SECONDS = 60 * 5;
              const validUntil = Math.floor(Date.now() / 1000) + VALID_SECONDS;
              // compute forward (0 here) and required message amount
              const forward = BigInt(0);
              const TON_FEE_BIG = ensureMessageAmount(forward, useDiagnosticLowFee);
              const TON_FEE = TON_FEE_BIG.toString();
              const recipientAddress = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : (recipient as string);

              const tx = {
                validUntil,
                messages: [
                  {
                    // send payload to selected recipient
                    address: recipientAddress,
                    amount: TON_FEE,
                    payload: payloadBase64,
                  },
                ],
              };

              const txJson = JSON.stringify(tx, null, 2);
              console.log('TEST PAYLOAD TX', txJson);
              setLastTxJson(txJson);
              // send through TonConnect UI
              await tonConnectUI.sendTransaction(tx as any);
              alert('페이로드 포함 전송 요청을 보냈습니다. 지갑에서 확인하세요.');
            } catch (e) {
              console.error('payload tx failed', e);
              alert('payload 전송 실패: ' + (e && (e as any).message ? (e as any).message : String(e)));
            } finally {
              setBusy(false);
            }
          }}
          style={{ padding: '8px 12px', fontSize: 14 }}
        >
          Payload 포함 전송 (테스트)
        </button>
        <button
          onClick={async () => {
            try {
              setBusy(true);
              if (!connectedWallet) { alert('지갑을 먼저 연결해주세요.'); return; }
              const DECIMALS = 9n;
              const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
              const amount = amountWhole * 10n ** DECIMALS;
              const recipientForPayload = manualJettonWallet && manualJettonWallet.length > 0 ? manualJettonWallet : null;
              if (!recipientForPayload) { alert('Jetton wallet 주소를 파생할 수 없습니다. 수동으로 jetton-wallet 주소를 입력하세요.'); setBusy(false); return; }
              const toAddress = Address.parse(recipientForPayload as string);
              const responseAddr = includeResponseTo ? Address.parse(connectedWallet.account.address) : null;
              const payloadCell = buildJettonTransferPayload(amount, toAddress, responseAddr);
              const payloadBase64 = payloadCell.toBoc().toString('base64');
              const VALID_SECONDS = 60 * 5;
              const forward = BigInt(0);
              const TON_FEE_BIG = ensureMessageAmount(forward, useDiagnosticLowFee);
              const TON_FEE = TON_FEE_BIG.toString();
              const recipientAddr = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : (recipientForPayload as string);
              const tx = { validUntil: Math.floor(Date.now() / 1000) + VALID_SECONDS, messages: [{ address: recipientAddr, amount: TON_FEE, payload: payloadBase64 }] };
              const txJson = JSON.stringify(tx, null, 2);
              setLastTxJson(txJson);
              console.log('TEST DIRECT PAYLOAD -> jetton-wallet', txJson);
              await tonConnectUI.sendTransaction(tx as any);
            } catch (e) { console.error('direct payload tx failed', e); alert('직접 전송 실패: ' + ((e as any)?.message ?? String(e))); } finally { setBusy(false); }
          }}
          style={{ padding: '8px 12px', fontSize: 14 }}
        >
          Payload → jetton-wallet (직접 전송 테스트)
        </button>
      </div>

      {/* Derived jetton-wallet info */}
        <div style={{ marginTop: 10 }}>
          <strong>Jetton 수신지</strong>
        <div style={{ marginTop: 6 }}>
          {/* when sendToTokenMaster is on, show token master address in read-only mode */}
          {(() => {
            const displayed = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : manualJettonWallet;
            return (
              <div>
                <input
                  value={displayed ?? ''}
                  onChange={(e) => { setManualJettonWallet(e.target.value); }}
                  style={{ width: '100%', maxWidth: 560 }}
                  placeholder={'수동으로 jetton-wallet 주소를 입력하거나 Auto-derive로 시도하세요'}
                />
                <div style={{ marginTop: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
                  <button onClick={tryAutoDerive} style={{ padding: '6px 10px' }}>Auto-derive jetton-wallet</button>
                  <span style={{ color: '#666' }}>{deriveStatus ?? ''}</span>
                </div>
              </div>
            );
          })()}
        </div>
        <div style={{ marginTop: 8 }}>
          <button onClick={() => { const v = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : manualJettonWallet; if (v) { navigator.clipboard.writeText(v); alert('Jetton wallet 주소 복사됨'); } else { alert('복사할 주소가 없습니다'); } }}>주소 복사</button>
          <span style={{ marginLeft: 12, color: '#666' }}>{sendToTokenMaster ? 'Token Master 대상 사용 중' : '수동 jetton-wallet 주소 사용'}</span>
        </div>
        <div style={{ marginTop: 8 }}>
          <label>
            <input type="checkbox" checked={sendToTokenMaster} onChange={(e) => setSendToTokenMaster(e.target.checked)} /> 보내기 대상: Token Master 사용
          </label>
        </div>
        <div style={{ marginTop: 8 }}>
          <label>
            <input type="checkbox" checked={forceTokenPresentation} onChange={(e) => setForceTokenPresentation(e.target.checked)} /> Force token presentation (지갑에 token transfer UI 표출을 시도)
          </label>
        </div>
        <div style={{ marginTop: 8 }}>
          <label>
            <input type="checkbox" checked={pocMode} onChange={(e) => setPocMode(e.target.checked)} /> PoC 모드 (잔액 검사 우회)
          </label>
        </div>
      </div>

      {/* Add token symbol/amount preview */}
      <div style={{ marginTop: 8 }}>
        <span style={{ color: '#333' }}>{depositAmount || '0'} CSPIN</span>
      </div>

      {/* 수동 증빙 (Manual evidence) */}
      <div style={{ marginTop: 12, padding: 10, border: '1px dashed #e6e6e6', borderRadius: 6 }}>
        <strong>수동 증빙 추가</strong>
        <div style={{ marginTop: 8 }}>
          <textarea value={manualEvidenceText} onChange={(e) => setManualEvidenceText(e.target.value)} placeholder="오류 로그 또는 트랜잭션 설명을 붙여넣으세요." style={{ width: '100%', height: 90, fontSize: 13 }} />
          <div style={{ marginTop: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <button onClick={addManualEvidence} style={{ padding: '6px 10px' }}>증빙 추가</button>
            <label style={{ display: 'inline-block', padding: '6px 10px', background: '#f5f5f5', borderRadius: 4, cursor: 'pointer' }}>
              파일 업로드
              <input type="file" style={{ display: 'none' }} onChange={(ev) => { const f = (ev.target as HTMLInputElement).files?.[0] ?? null; handleFileUpload(f); }} />
            </label>
            <button onClick={downloadEvidencePack} style={{ padding: '6px 10px' }}>증빙 팩 다운로드</button>
          </div>
        </div>

        {evidenceList.length > 0 && (
          <div style={{ marginTop: 10 }}>
            <strong>저장된 증빙</strong>
            <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {evidenceList.map(e => (
                <div key={e.id} style={{ padding: 8, border: '1px solid #efefef', borderRadius: 6, background: '#fff' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ fontSize: 13 }}><strong>{e.name}</strong> <span style={{ color: '#666', fontSize: 12 }}>&nbsp;·&nbsp;{new Date(e.created).toLocaleString()}</span></div>
                    <div>
                      <button onClick={() => { navigator.clipboard.writeText(e.content); alert('증빙 내용이 복사되었습니다.'); }}>복사</button>
                      <button style={{ marginLeft: 8 }} onClick={() => { const blob = new Blob([e.content], { type: 'text/plain' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = e.name; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); }}>다운로드</button>
                      <button style={{ marginLeft: 8 }} onClick={() => removeEvidence(e.id)}>삭제</button>
                    </div>
                  </div>
                  <pre style={{ whiteSpace: 'pre-wrap', marginTop: 8, fontSize: 12 }}>{e.content.slice(0, 1000)}</pre>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Last TX JSON display + variant test buttons */}
      <div style={{ marginTop: 12 }}>
        <strong>최근 전송 TX JSON (복사 가능)</strong>
        <div style={{ marginTop: 8 }}>
          <textarea readOnly value={lastTxJson ?? ''} style={{ width: '100%', height: 140, fontSize: 12 }} />
        </div>
        <div style={{ marginTop: 8 }}>
          <button onClick={() => { if (lastTxJson) { navigator.clipboard.writeText(lastTxJson); alert('TX JSON이 클립보드에 복사되었습니다.'); } else { alert('복사할 TX JSON이 없습니다.'); } }}>TX JSON 복사</button>
          <button style={{ marginLeft: 8 }} onClick={() => setLastTxJson(null)}>지우기</button>
          <button style={{ marginLeft: 8 }} onClick={downloadDebugPack}>디버그 팩 다운로드</button>
        </div>

        <div style={{ marginTop: 12, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button onClick={async () => {
            // variant: omit response_to
            try {
              setBusy(true);
              const DECIMALS = 9n;
              const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
              const amount = amountWhole * 10n ** DECIMALS;
              const recipientForPayload = manualJettonWallet && manualJettonWallet.length > 0 ? manualJettonWallet : null;
              if (!recipientForPayload) {
                alert('Jetton wallet 주소를 파생할 수 없습니다. 수동으로 jetton-wallet 주소를 입력하세요.');
                setBusy(false);
                return;
              }
              const toAddress = Address.parse(recipientForPayload as string);
              const payloadCell = buildJettonTransferPayloadVariant(amount, toAddress, null, BigInt(0));
              const payloadBase64 = payloadCell.toBoc().toString('base64');
              const VALID_SECONDS = 60 * 5;
              const tx = { validUntil: Math.floor(Date.now() / 1000) + VALID_SECONDS, messages: [{ address: recipientForPayload as string, amount: (useDiagnosticLowFee ? toNano('0.05') : toNano('1.1')).toString(), payload: payloadBase64 }] };
              const txJson = JSON.stringify(tx, null, 2);
              setLastTxJson(txJson);
              console.log('VARIANT omit response_to', txJson);
              await tonConnectUI.sendTransaction(tx as any);
            } catch (e) {
              console.error('variant omit failed', e);
              alert('variant omit failed: ' + ((e as any)?.message ?? String(e)));
            } finally { setBusy(false); }
          }}>Variant: omit response_to</button>

          <button onClick={async () => {
            // variant: set forward TON to 1 TON
            try {
              setBusy(true);
              const DECIMALS = 9n;
              const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
              const amount = amountWhole * 10n ** DECIMALS;
              const recipientForPayload = manualJettonWallet && manualJettonWallet.length > 0 ? manualJettonWallet : null;
              if (!recipientForPayload) {
                alert('Jetton wallet 주소를 파생할 수 없습니다. 수동으로 jetton-wallet 주소를 입력하세요.');
                setBusy(false);
                return;
              }
              const toAddress = Address.parse(recipientForPayload as string);
              const forward = toNano('1');
              // include forward in payload and ensure message.amount covers forward plus fee margin
              const payloadCell = buildJettonTransferPayloadVariant(amount, toAddress, includeResponseTo ? Address.parse(connectedWallet.account.address) : null, forward);
              const payloadBase64 = payloadCell.toBoc().toString('base64');
              const VALID_SECONDS = 60 * 5;
              // ensure message TON amount includes forward plus a fee margin
              const msgAmountBig = ensureMessageAmount(forward, useDiagnosticLowFee);
              const recipientAddr = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : (recipientForPayload as string);
              const tx = { validUntil: Math.floor(Date.now() / 1000) + VALID_SECONDS, messages: [{ address: recipientAddr, amount: msgAmountBig.toString(), payload: payloadBase64 }] };
              const txJson = JSON.stringify(tx, null, 2);
              setLastTxJson(txJson);
              console.log('VARIANT forward 1 TON (encoded in payload structure)', txJson);
              await tonConnectUI.sendTransaction(tx as any);
            } catch (e) {
              console.error('variant forward failed', e);
              alert('variant forward failed: ' + ((e as any)?.message ?? String(e)));
            } finally { setBusy(false); }
          }}>Variant: forward 1 TON</button>

          <button onClick={async () => {
            // diagnostic: send with higher TON fee (2.5 TON) to rule out fee/simulation mismatch
            try {
              setBusy(true);
              const DECIMALS = 9n;
              const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
              const amount = amountWhole * 10n ** DECIMALS;
              const toAddress = Address.parse(GAME_WALLET_ADDRESS);
              const responseAddr = includeResponseTo ? Address.parse(connectedWallet.account.address) : null;
              const payloadCell = buildJettonTransferPayload(amount, toAddress, responseAddr);
              const payloadBase64 = payloadCell.toBoc().toString('base64');
              const VALID_SECONDS = 60 * 5;
              const highFeeBig = toNano('2.5');
              const recipientAddr = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : toAddress.toString();
              const tx = { validUntil: Math.floor(Date.now() / 1000) + VALID_SECONDS, messages: [{ address: recipientAddr, amount: highFeeBig.toString(), payload: payloadBase64 }] };
              const txJson = JSON.stringify(tx, null, 2);
              setLastTxJson(txJson);
              console.log('DIAG high-fee payload tx', txJson);
              await tonConnectUI.sendTransaction(tx as any);
            } catch (e) {
              console.error('high-fee payload failed', e);
              alert('high-fee payload failed: ' + ((e as any)?.message ?? String(e)));
            } finally { setBusy(false); }
          }}>Diagnostic: High TON fee (2.5 TON)</button>

          <button onClick={async () => {
            // variant: opcode override to a different value (for testing)
            try {
              setBusy(true);
              const DECIMALS = 9n;
              const amountWhole = BigInt(Math.max(0, Number(depositAmount)));
              const amount = amountWhole * 10n ** DECIMALS;
              const recipientForPayload = manualJettonWallet && manualJettonWallet.length > 0 ? manualJettonWallet : null;
              if (!recipientForPayload) {
                alert('Jetton wallet 주소를 파생할 수 없습니다. 수동으로 jetton-wallet 주소를 입력하세요.');
                setBusy(false);
                return;
              }
              const toAddress = Address.parse(recipientForPayload as string);
              const responseAddr = includeResponseTo ? Address.parse(connectedWallet.account.address) : null;
              const payloadCell = buildJettonTransferPayloadVariant(amount, toAddress, responseAddr, BigInt(0), 0x12345678);
              const payloadBase64 = payloadCell.toBoc().toString('base64');
              const VALID_SECONDS = 60 * 5;
              const msgAmountBig = ensureMessageAmount(BigInt(0), useDiagnosticLowFee);
              const recipientAddr = sendToTokenMaster ? CSPIN_TOKEN_ADDRESS : (recipientForPayload as string);
              const tx = { validUntil: Math.floor(Date.now() / 1000) + VALID_SECONDS, messages: [{ address: recipientAddr, amount: msgAmountBig.toString(), payload: payloadBase64 }] };
              const txJson = JSON.stringify(tx, null, 2);
              setLastTxJson(txJson);
              console.log('VARIANT opcode override', txJson);
              await tonConnectUI.sendTransaction(tx as any);
            } catch (e) {
              console.error('variant opcode failed', e);
              alert('variant opcode failed: ' + ((e as any)?.message ?? String(e)));
            } finally { setBusy(false); }
          }}>Variant: opcode override</button>
        </div>
      </div>

      {/* tx preview */}
      {txPreview && (
        <div style={{ marginTop: 12, padding: 12, border: '1px solid #e1e1e1', borderRadius: 6 }}>
          <strong>트랜잭션 미리보기</strong>
          <div style={{ fontSize: 13, marginTop: 8 }}>
            <div>To: {txPreview.to}</div>
            <div>Amount (nano): {txPreview.amount}</div>
            <div>ValidUntil: {new Date(txPreview.validUntil * 1000).toLocaleString()}</div>
            <div>Payload (prefix):</div>
            <div style={{ maxWidth: '100%', overflowX: 'auto', wordBreak: 'normal' }}>
              <code style={{ whiteSpace: 'pre', display: 'block' }}>{txPreview.payloadDisplay}</code>
            </div>
            <div style={{ marginTop: 8 }}>
              <button
                onClick={async () => {
                  // robust base64 -> Uint8Array helper that supports base64url and missing padding
                  function base64ToUint8Array(input: string): Uint8Array {
                    // remove whitespace
                    let s = input.replace(/\s+/g, '');
                    // base64url -> base64
                    s = s.replace(/-/g, '+').replace(/_/g, '/');
                    // pad with '=' to multiple of 4
                    while (s.length % 4 !== 0) {
                      s += '=';
                    }

                    // try browser atob first
                    try {
                      const bin = atob(s);
                      const bytes = new Uint8Array(bin.length);
                      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
                      return bytes;
                    } catch (e) {
                      // fallback to Buffer (polyfilled in app via polyfills.ts)
                      if (typeof (globalThis as any).Buffer !== 'undefined') {
                        const buf = (globalThis as any).Buffer.from(s, 'base64');
                        return new Uint8Array(buf);
                      }
                      throw e;
                    }
                  }

                  try {
                    const bytes = base64ToUint8Array(txPreview.payloadFull);
                    const hex = Array.from(bytes).map(x => x.toString(16).padStart(2, '0')).join('');
                    setDecodedPayloadHex(hex);

                    // try to use ton-core BOC parser if available
                    try {
                      // dynamic import to avoid bundling issues
                      const ton = await import('ton-core');
                      if ((ton as any).Cell && typeof (ton as any).Cell.fromBoc === 'function') {
                        const cells = (ton as any).Cell.fromBoc((globalThis as any).Buffer.from(txPreview.payloadFull, 'base64'));
                        const info = `Parsed cells: ${cells.length}`;
                        setDecodedCellInfo(info);
                      } else if (typeof (ton as any).deserializeBoc === 'function') {
                        const cells = (ton as any).deserializeBoc((globalThis as any).Buffer.from(txPreview.payloadFull, 'base64'));
                        setDecodedCellInfo(`Parsed cells: ${cells.length}`);
                      } else {
                        setDecodedCellInfo('No compatible BOC parser found in ton-core build.');
                      }
                    } catch (err) {
                      setDecodedCellInfo('BOC parse attempt failed: ' + String(err));
                    }
                  } catch (err) {
                    setDecodedPayloadHex('Failed to decode payload: ' + String(err));
                  }
                }}
              >
                Decode payload
              </button>
        
            {/* direct payload button moved to variant buttons for clearer layout */}
            </div>
          </div>
        </div>
      )}

      {showConfirmModal && (
        <div style={{ position: 'fixed', left: 0, right: 0, top: 0, bottom: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 720, background: '#fff', padding: 16, borderRadius: 8 }}>
            <h3>시뮬레이션 경고</h3>
            <div style={{ maxHeight: 300, overflow: 'auto', fontSize: 12, whiteSpace: 'pre-wrap' }}>{simResult ?? '시뮬레이션 정보 없음'}</div>
            <div style={{ marginTop: 12, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={() => { setShowConfirmModal(false); setSimResult(null); }}>취소</button>
              <button onClick={() => { setShowConfirmModal(false); setSimResult(null); /* proceed without blocking */ }}>계속 진행</button>
            </div>
          </div>
        </div>
      )}

      {decodedPayloadHex && (
        <div style={{ marginTop: 12, padding: 12, border: '1px solid #eee', borderRadius: 6 }}>
          <strong>Payload Hex</strong>
          <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12 }}>{decodedPayloadHex}</pre>
          {decodedCellInfo && <div style={{ marginTop: 8 }}>{decodedCellInfo}</div>}
        </div>
      )}

      {/* deep link helper when bridge fails */}
      {showDeepLink && (
        <div style={{ marginTop: 12, padding: 12, border: '1px solid #cce5ff', borderRadius: 6, background: '#f0f8ff' }}>
          <strong>브리지 연결 문제가 의심됩니다.</strong>
          <div style={{ marginTop: 8 }}>
            모바일에서 직접 지갑을 열어 승인해 보세요.
          </div>
          <div style={{ marginTop: 8 }}>
            <button
              onClick={() => {
                // open tg resolve for TON Wallet
                const url = `tg://resolve?domain=wallet&appname=start&startapp=tonconnect-v__2-id__${encodeURIComponent(
                  'manual-open'
                )}-ret__back`;
                window.location.href = url;
              }}
            >
              Open in Telegram Wallet
            </button>
            <button
              style={{ marginLeft: 8 }}
              onClick={() => {
                // fallback to wallet web deep link
                const url = `https://wallet.ton.org/`;
                window.open(url, '_blank');
              }}
            >
              Open Wallet Web
            </button>
          </div>
        </div>
      )}
      {lastError && (
        <div style={{ marginTop: 12, padding: 12, border: '1px solid #f1c40f', borderRadius: 6, background: '#fffbea' }}>
          <strong>마지막 오류 (복사 가능):</strong>
          <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12 }}>{lastError}</pre>
          <div style={{ marginTop: 8 }}>
            <button
              onClick={() => {
                try {
                  navigator.clipboard.writeText(lastError as string);
                  alert('오류 내용이 클립보드에 복사되었습니다.');
                } catch (e) {
                  alert('클립보드 복사에 실패했습니다. 콘솔에서 오류를 확인하세요.');
                }
              }}
            >
              오류 복사
            </button>
            <button
              style={{ marginLeft: 8 }}
              onClick={() => {
                // quick retry (user-initiated)
                setLastError(null);
              }}
            >
              오류 지우기
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PoCComponent;
